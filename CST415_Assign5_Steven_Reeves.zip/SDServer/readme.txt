/*
 * Steven Reeves 
 * 12/3/2017
 * CST 415
 * Assignment #5
 */
 
 - PRSCServiceClient stubbed out 
 - Post not implemented